Générateur de photo d'identité
==============================
Ce programme a pour but de simplifier la réalisation de photos d'identités. Ainsi on prend une photo (ou on en importe une) on localise le visage de la personne et on génère ainsi directement une planche avec quatre photos prêtes à être imprimées.

Pour plus d'information reportez vous à la page web associée à ce projet : http://karlito139.github.com/generateur-de-photo-identite.



Installation
============
Pour compiler ce logiciel il vous faudra tout d'abord avoir installé la librairie QT ainsi que opencv. Une fois ceci fait, si vous êtes sous windows il faudra modifier le fichier .pro pour indiquer où se trouve votre librairie opencv.

Une fois tout installé vous pourez configurer le projet :

qmake

Puis le compiler :

make
