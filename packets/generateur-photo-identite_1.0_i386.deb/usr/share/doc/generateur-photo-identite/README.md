Generateur de photo d'identitée
===============================

Ce programme a pour but de simplifier la réalisation de photos d'identés. Ainsi on prend une photo (ou on en importe une) on localise le visage de la personne et on créé ainsi directement une planche avec 4 photos prètes à être imprimées.
