Générateur de photo d'identité
==============================
Ce programme a pour but de simplifier la réalisation de photos d'identités. Ainsi on prend une photo (ou on en importe une) on localise le visage de la personne et on génère ainsi directement une planche avec quatre photos prêtes à être imprimées.

Pour plus d'information reportez vous à la page web associée à ce projet : http://karlito139.github.com/generateur-de-photo-identite
